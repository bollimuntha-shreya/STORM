storm\_kit.mpc.cost.projected\_dist\_cost module
================================================

.. automodule:: storm_kit.mpc.cost.projected_dist_cost
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:
