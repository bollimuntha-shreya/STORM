storm\_kit.mpc.model.urdf\_kinematic\_model\_baseline module
============================================================

.. automodule:: storm_kit.mpc.model.urdf_kinematic_model_baseline
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:
