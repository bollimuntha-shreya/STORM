storm\_kit.mpc.cost.robot\_self\_collision\_cost module
=======================================================

.. automodule:: storm_kit.mpc.cost.robot_self_collision_cost
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:
