storm\_kit.mpc.cost.primitive\_collision\_cost module
=====================================================

.. automodule:: storm_kit.mpc.cost.primitive_collision_cost
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:
