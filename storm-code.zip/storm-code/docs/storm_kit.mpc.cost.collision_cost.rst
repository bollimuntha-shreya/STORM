storm\_kit.mpc.cost.collision\_cost module
==========================================

.. automodule:: storm_kit.mpc.cost.collision_cost
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:
