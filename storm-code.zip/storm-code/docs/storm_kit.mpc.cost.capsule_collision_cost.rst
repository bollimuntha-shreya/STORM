storm\_kit.mpc.cost.capsule\_collision\_cost module
===================================================

.. automodule:: storm_kit.mpc.cost.capsule_collision_cost
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:
