storm\_kit.mpc.control.olgaussian\_mpc module
=============================================

.. automodule:: storm_kit.mpc.control.olgaussian_mpc
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:
